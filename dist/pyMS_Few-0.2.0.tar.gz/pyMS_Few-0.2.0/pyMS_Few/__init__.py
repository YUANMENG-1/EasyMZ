#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jun  1 19:43:04 2025

@author: yuanmengyi
"""

# pyMS_Few/__init__.py
__version__ = "0.2.0"
# pyMS_Few

1.A pipeline for processing mzML files on macOS Intel x86_64.
2.In the clustering process, version 0.1.3 & 0.1.6  operates on partitioned data segments
whereas the 0.1.4 & 0.1.7 performs clustering globally across the entire dataset.
Major differences on 02_bind_no_noise_modi3.cpp or 02_bind_no_noise_modi2.cpp
3.0.05 not 0.005 in setp07&08  
4.noise 250 of 0.1.5
5.Modified of 4
6.Modi of <5 data points clusters and filter metrics with 5 top intensity.

## Installation

```bash
pip install pyMS_Few